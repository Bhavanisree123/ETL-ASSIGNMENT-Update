import sqlite3
import pandas as pd
import csv
connection_obj = sqlite3.connect('S30 ETL Assignment.db')
cursor_obj = connection_obj.cursor()

#one solution with pure-sql

data=cursor_obj.execute('''SELECT c.customer_id as Customer,c.age as Age,i.item_name as Item, sum(o.quantity)as Quantity from Customers c inner join Sales s inner join items i inner join orders o on c.customer_id = s.customer_id and
o.sales_id = s.sales_id and  o.item_id = i.item_id WHERE Quantity IS NOT NULL GROUP BY c.customer_id,i.item_id having c.age between 18 and 35  ;''')
with open("output_puresql.csv", "w") as csv_file:
      csv_writer = csv.writer(csv_file, delimiter=";")
      csv_writer.writerow([i[0] for i in data.description])
      csv_writer.writerows(data)

#one solution with pandas
db_df = pd.read_sql_query('''SELECT c.customer_id as Customer,c.age as Age,i.item_name as Item, sum(o.quantity)as Quantity from Customers c inner join Sales s inner join items i inner join orders o on c.customer_id = s.customer_id and
o.sales_id = s.sales_id and  o.item_id = i.item_id WHERE Quantity IS NOT NULL GROUP BY c.customer_id,i.item_id having c.age between 18 and 35  ;''', connection_obj)
db_df.to_csv('output_pandas.csv',sep=';', index=False)

connection_obj.close()
